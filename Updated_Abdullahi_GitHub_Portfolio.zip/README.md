
# Abdullahi Abdurrashid's Portfolio

👷‍♂️ **Civil Engineer | Structural Designer | AI Enthusiast**

Welcome to my portfolio! I am a passionate Civil Engineer with a focus on structural design and construction solutions, blending traditional engineering with modern technologies like AI.

## About Me
I specialize in:
- **Smart Infrastructure**
- **Reinforced Concrete Design**
- **Structural Reliability**
- **AI in Engineering Workflows**

### Tools I Use:
- AutoCAD, STAAD.Pro, MATLAB
- Python, Excel, Revit

## Contact
You can reach me at:
- 📩 Email: abdullahi@example.com
- 🔗 LinkedIn: [linkedin.com/in/abdullahi](https://linkedin.com/in/abdullahi)

Feel free to explore my projects and connect with me!
